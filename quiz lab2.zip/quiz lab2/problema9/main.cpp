#include <iostream>
#include <string.h>
using namespace std;

int CambiarCharInt(char cad[], int limIn, int limSup);

int main()
{

    int n;
    char cadNums[50];
    cout << "Ingrese el numero n: ";
    cin >> n;

    cout << "\nIngrese la cadena de caracteres numericos: ";
    cin >> cadNums;

    int tamCad = strlen(cadNums);

        int numCeros = 0, numSegmentado, sum = 0;

        if (tamCad%n != 0) { // el caso en que no se puede dividir en numeros de n cifras
            while ( (tamCad + numCeros)%n != 0) //
                numCeros++; //cuenta la cantidad de ceros
        }
        for (int i = 0; i<(tamCad + numCeros)/n; i++) {
            if (numCeros == 0){ //  sí se puede dividir en numeros de n cifras.
                numSegmentado = CambiarCharInt(cadNums, i*n, (i + 1)*n - 1);

            }else { // Caso en que no se puede dividir en numeros de n cifras
                if (i == 0) { // Considero el primer numero a obtener, que el diferente respecto a las n cifras
                    numSegmentado = CambiarCharInt(cadNums, i*n, (i + 1)*n - 1 - numCeros);

                }else
                    numSegmentado = CambiarCharInt(cadNums, i*n - numCeros, (i + 1)*n - 1 - numCeros);

            }sum += numSegmentado;
        }
        cout << "Original: ";
        for (int i = 0; i<tamCad; i++)
            cout << *(cadNums + i);
        cout<<endl;
        cout << "Suma : " << sum << endl;





 return 0;

}
int CambiarCharInt(char cad[], int limIn, int limSup) {

    int num=0;

    for (int i = limIn; i<=limSup; i++) {
        num = num*10 + (*(cad + i) - 48);
    }
    return num;


}
