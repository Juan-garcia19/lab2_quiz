#include <iostream>
#include <string.h>

//este programa recibe caracter a caracter, no se pueden ingresar mas de uno

using namespace std;

int CambiarCharInt(char cad[], int limIn, int limSup);

int main()
{
    char caracter;

    char arr[50]={};
    int cont=0;
    do{
        cout<<"ingrese caracter:";
        cin>>caracter;
        for(int i=0;i<50;i++){
            if (cont==i and caracter!='*'){
            arr[i]+=caracter;
            }
        }
        cont++;
    }while(caracter!='*');

    //punto numero 8
    int itertxt=0,iternum=0,tamCad = strlen(arr);
    char texto[50]={},numeros[50]={};

    for (int i=0;i<tamCad;i++){
        if ((arr[i]>=65 and arr[i]<=90) || (arr[i]>=97 and arr[i]<=122)){
            texto[itertxt]=arr[i];
            itertxt++;
        }
        else{
            numeros[iternum]=arr[i];
            iternum++;
        }
    }
    //punto numero 9
    int n=3,tamNum=strlen(numeros),tamCar=strlen(texto);
    int numCeros = 0, numSegmentado, sum = 0;

    if (tamNum%n != 0) {
        while ( (tamNum + numCeros)%n != 0) //
            numCeros++;
    }
    for (int i = 0; i<(tamNum + numCeros)/n; i++) {
        if (numCeros == 0){
            numSegmentado = CambiarCharInt(numeros, i*n, (i + 1)*n - 1);
        }else {
            if (i == 0) {
                numSegmentado = CambiarCharInt(numeros, i*n, (i + 1)*n - 1 - numCeros);

            }else
                numSegmentado = CambiarCharInt(numeros, i*n - numCeros, (i + 1)*n - 1 - numCeros);

        }sum += numSegmentado;
    }
    cout << "Original: ";
    for (int i = 0; i<tamNum; i++)
        cout << *(numeros + i);
    cout<<endl;
    cout << "Suma : " << sum << endl;

    int mayor=0,contador=0;
    for (int i = 0; i<tamNum;i++){
        if (mayor<numeros[i]){
            mayor=numeros[i];
        }
        if (mayor==numeros[i]){
            contador++;
        }
    }
    int mayorc=0,contadorc=0;
    for (int i = 0; i<tamCar;i++){
        if (mayorc<texto[i]){
            mayorc=texto[i];
        }
        if (mayorc==texto[i]){
            contadorc++;
        }
    }
    cout<<char(mayorc)<<" aparece ("<<contadorc<<") y el digito "<<mayor-48<<" ("<<contador<<") vez"<<endl;
    return 0;
}

int CambiarCharInt(char cad[], int limIn, int limSup) {

    int num=0;

    for (int i = limIn; i<=limSup; i++) {
        num = num*10 + (*(cad + i) - 48);
    }
    return num;


}
