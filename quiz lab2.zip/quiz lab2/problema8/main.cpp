#include <iostream>

using namespace std;

int main()
{
    char caracteres[]="absd342";
    int tamano=sizeof (caracteres)-1;
    char texto[7]={};
    char numeros[7]={};

    int itertxt=0,iternum=0;

    for (int i=0;i<tamano;i++){
        if ((caracteres[i]>=65 and caracteres[i]<=90) || (caracteres[i]>=97 and caracteres[i]<=122)){
            texto[itertxt]=caracteres[i];
            itertxt++;
        }
        else{
            numeros[iternum]=caracteres[i];
            iternum++;
        }
    }

    cout<<caracteres<<endl;
    cout<<texto<<endl;
    cout<<numeros<<endl;

    return 0;
}
